# Chapter 2 - Time-Series Analysis with Python

The CSV file `spm.csv` was downloaded from the [Our World in Data github repository](https://github.com/owid/owid-datasets/blob/master/datasets) (Air pollution by city - Fouquet and DPCC).

The global temperatures were downloaded from [Datahub](https://datahub.io/core/global-temp).

